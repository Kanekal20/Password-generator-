from sys import argv
from .xkcd_password import main

exit(main(argv))
